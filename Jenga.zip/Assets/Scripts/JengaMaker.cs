using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class JengaMaker : MonoBehaviour
{
    //public JSONReader jsonReader;

    public GameObject glassCube;
    public GameObject woodCube;
    public GameObject stoneCube;

    public GameObject labelPrefab;
    public GameObject stackPrefab;

    public List<StudentsData> sortedData,grade6Data, grade7Data, grade8Data;

    public GameObject tower6, tower7, tower8;

    private void Start()
    {


    }

    public void CreateJenga(StudentsData[] data)
    {
        grade6Data = new List<StudentsData>();
        grade7Data = new List<StudentsData>();
        grade8Data = new List<StudentsData>();
        SortStudentsData(data);

        CreateTower(grade6Data, tower6);
        CreateTower(grade8Data, tower8);
        CreateTower(grade7Data, tower7);



    }

    private void SortStudentsData(StudentsData[] data)
    {
        // Sort data by domain, cluster, and standard ID
        sortedData = new List<StudentsData>(data);
        sortedData.Sort((a, b) =>
        {
            int domainCompare = a.domain.CompareTo(b.domain);
            if (domainCompare == 0)
            {
                int clusterCompare = a.cluster.CompareTo(b.cluster);
                if (clusterCompare == 0)
                {
                    return a.standardid.CompareTo(b.standardid);
                }
                return clusterCompare;
            }
            return domainCompare;
        });

        // Separate data into lists by grade
        foreach (StudentsData d in sortedData)
        {
            if (d.grade == "6th Grade")
            {
                grade6Data.Add(d);
            }
            else if (d.grade == "7th Grade")
            {
                grade7Data.Add(d);
            }
            else if (d.grade == "8th Grade")
            {
                grade8Data.Add(d);
            }
        }
    }


    private void CreateTower(List<StudentsData> datas, GameObject towerBase)
    {

        JengaManager jengaManager = towerBase.GetComponent<JengaManager>();
        // Calculate block width and height from prefab
        Renderer blockRenderer = woodCube.GetComponent<Renderer>();
        float blockWidth = blockRenderer.bounds.size.x;
        float blockHeight = blockRenderer.bounds.size.y;
        float gapSize = blockWidth - blockRenderer.bounds.size.z * 3.25f;

        float movementSize = (blockWidth / 2 - gapSize);

        List<StudentsData> data = datas;
        // Calculate number of levels based on data count
        int numLevels = Mathf.CeilToInt((float)data.Count / 3f);

        Vector3 position = towerBase.transform.position;
        Quaternion rotation = Quaternion.identity;
        bool shouldRotate = false;

        for (int level = 0; level < numLevels; level++)
        {
            for (int block = 0; block < 3; block++)
            {
                GameObject jengaBlock;
                int dataIndex = level * 3 + block;
                if (dataIndex < data.Count)
                {
                    jengaBlock = Instantiate(data[level * 3 + block].mastery == 0 ? glassCube : data[level * 3 + block].mastery == 1 ? woodCube : stoneCube, position, rotation, towerBase.transform);
                    jengaManager.AddBlock(data[level * 3 + block], jengaBlock);
                }
                else
                {
                    break;
                }


                if (shouldRotate)
                {
                    position += towerBase.transform.right * movementSize;
                    jengaBlock.transform.Rotate(Vector3.up, 90f, Space.Self);
                }

                else
                {
                    position += towerBase.transform.forward * movementSize;
                }

            }

            if (shouldRotate)
            {
                position -= towerBase.transform.right * movementSize * 3;
                position -= towerBase.transform.forward * movementSize;
                position += towerBase.transform.right * movementSize;

            }
            else
            {
                position += towerBase.transform.forward * movementSize;
                position -= towerBase.transform.forward * movementSize * 3;
                position -= towerBase.transform.right * movementSize;

            }
            position += towerBase.transform.up * blockHeight;
            shouldRotate = !shouldRotate;

        }


    }
}
