using UnityEngine;

public class JengaTower : MonoBehaviour
{
    public GameObject jengaBlockPrefab; // The prefab for a single Jenga block
    public int numLevels = 6; // The number of levels in the tower
    public float blockWidth = 1.5f; // The width of a single block
    public float blockHeight = 0.5f; // The height of a single block
    public float blockDepth = 0.75f; // The depth of a single block

    void Start()
    {
        // Calculate the initial position of the first block
        Vector3 position = transform.position + new Vector3(0f, blockHeight / 2f, 0f);

        // Create the Jenga tower
        for (int level = 0; level < numLevels; level++)
        {
            // Determine the starting position of the first block in the level
            Vector3 levelPosition = position + new Vector3(blockWidth / 2f, 0f, blockDepth / 2f);

            // Create the three blocks in the level
            for (int block = 0; block < 3; block++)
            {
                // Instantiate a new block at the current position
                GameObject jengaBlock = Instantiate(jengaBlockPrefab, levelPosition, Quaternion.identity);

                // Add the block to the tower parent object for organization
                jengaBlock.transform.parent = transform;

                // Move the position up to the next block
                levelPosition += new Vector3(0f, blockHeight, 0f);
            }

            // Rotate the level for the next row
            position += new Vector3(blockWidth, 0f, 0f);
            transform.Rotate(Vector3.up, 90f);
        }
    }
}
