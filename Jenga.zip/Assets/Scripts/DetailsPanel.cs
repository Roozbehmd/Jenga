using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DetailsPanel : MonoBehaviour
{
    public GameObject selectedObject;
    public TextMeshProUGUI gradeDomain;
    public TextMeshProUGUI cluster;
    public TextMeshProUGUI description;
    public GameObject panel;

    private void Start()
    {
        panel.SetActive(false);
    }

    private void Update()
    {

        //check raycast on right click
        if (Input.GetMouseButtonDown(1))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            
            if (Physics.Raycast(ray, out hit))
            {
                panel.SetActive(true);
                GameObject hitObject = hit.collider.gameObject;
                selectedObject = hitObject;

                //check if raycast hit a jenga block, if so display it's details
                BlockInfo blockInfo = hitObject.GetComponent<BlockInfo>();
                if (blockInfo != null)
                {
                    gradeDomain.text = blockInfo.blockData.grade + " : " + blockInfo.blockData.domain;
                    cluster.text = blockInfo.blockData.cluster;
                    description.text = blockInfo.blockData.standarddescription;

                }
            }
        }
    }
}