using UnityEngine;
using System.Collections.Generic;

using UnityEngine.EventSystems;

public class OrbitCamera : MonoBehaviour
{
    public List<Transform> targets;
    public Transform target;
    private int currentTargetIndex=1;
    public float distance = 10.0f;
    public float xSpeed = 120.0f;
    public float ySpeed = 120.0f;
    public float yMinLimit = -20f;
    public float yMaxLimit = 80f;
    public float distanceMin = 0.5f;
    public float distanceMax = 15f;
    private Rigidbody rigidbody;
    private float x = 0.0f;
    private float y = 0.0f;

    private Vector3 targetPosition;
    private Quaternion targetRotation;
    private float moveSpeed = 15f;

    public GameObject detailsPanel;

    void Start()
    {
        Vector3 angles = transform.eulerAngles;
        x = angles.y;
        y = angles.x;
        rigidbody = GetComponent<Rigidbody>();
        if (rigidbody != null)
        {
            rigidbody.freezeRotation = true;
        }

        // Update camera position and rotation when target changes
        UpdateCamera(true);
    }

    public void NextTarget()
    {
        if(currentTargetIndex < targets.Count - 1)
        {
            currentTargetIndex++;
            SetTarget(targets[currentTargetIndex]);
        }
        else
        {
            currentTargetIndex = 0;
            SetTarget(targets[currentTargetIndex]);
        }
        

    }

    void LateUpdate()
    {
        if (!EventSystem.current.IsPointerOverGameObject()) // check if  mouse not hovering over UI element
        {

            
            if (Input.GetMouseButton(0)) // check if left mouse button is held down
            {

                //turn off detail panel when mouse is clicked
                detailsPanel.SetActive(false);

                if (target)
                {
                    x += Input.GetAxis("Mouse X") * xSpeed * distance * 0.02f;
                    y -= Input.GetAxis("Mouse Y") * ySpeed * 0.02f;

                    y = ClampAngle(y, yMinLimit, yMaxLimit);
                    Cursor.lockState = CursorLockMode.Locked;
                }
            }
            else
            {
                Cursor.lockState = CursorLockMode.None;
            }

            // Always update camera distance with mouse scroll wheel
            distance = Mathf.Clamp(distance - Input.GetAxis("Mouse ScrollWheel") * 5, distanceMin, distanceMax);

            // Update camera position and rotation when target changes
            if (target != null) UpdateCamera(false);
        }
        
    }

    //angle restrictions
    public static float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360F)
        {
            angle += 360F;
        }
        if (angle > 360F)
        {
            angle -= 360F;
        }
        return Mathf.Clamp(angle, min, max);
    }

    // Public method to update the target object and camera position/rotation
    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
        UpdateCamera(false);
    }

    // Private method to update the camera position/rotation based on the current target object and camera settings
    private void UpdateCamera(bool instant)
    {
        Quaternion rotation = Quaternion.Euler(y, x, 0);

        Vector3 negDistance = new Vector3(0.0f, 0.0f, -distance);
        Vector3 position = rotation * negDistance + target.position;

        if (instant)
        {
            transform.rotation = rotation;
            transform.position = position;
        }
        else
        {
            targetPosition = position;
            targetRotation = rotation;
        }
    }

    void FixedUpdate()
    {
        if (target != null && !targetPosition.Equals(Vector3.zero) && !targetRotation.Equals(Quaternion.identity))
        {
            transform.position = Vector3.Lerp(transform.position, targetPosition + new Vector3(0, 1, 0), Time.fixedDeltaTime * moveSpeed) ;
            transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, Time.fixedDeltaTime * moveSpeed);

            if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
            {
                targetPosition = Vector3.zero;
                targetRotation = Quaternion.identity;
            }
        }
    }
}
