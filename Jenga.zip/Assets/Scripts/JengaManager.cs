using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JengaManager : MonoBehaviour
{
    [SerializeField] private List<BlockData> jengaBlocks = new List<BlockData>();

    private void Start()
    {

    }
    public void AddBlock(StudentsData data, GameObject jengaBlock)
    {
        BlockData newBlockData = new BlockData();
        newBlockData.block = jengaBlock;
        newBlockData.grade = data.grade;
        newBlockData.mastery = data.mastery;
        newBlockData.domain = data.domain;
        newBlockData.standarddescription = data.standarddescription;
        newBlockData.cluster = data.cluster;

        jengaBlocks.Add(newBlockData);

        newBlockData.block.GetComponent<BlockInfo>().blockData = newBlockData;
    }



    public void TestStack()
    {
        foreach(BlockData blockData in jengaBlocks)
        {
            //turn on gravity
            blockData.block.GetComponent<Rigidbody>().isKinematic = false;

            //Turn off the block if it's made of glass
            if(blockData.mastery == 0)
            {
                blockData.block.SetActive(false);
            }
        }
    }
}

public class BlockData
{
    public GameObject block;
    public string grade;
    public int mastery;
    public string domain;
    public string cluster;
    public string standarddescription;

}