using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public List<JengaManager> jengaManagers = new List<JengaManager>();
    public GameObject mainCamera;
    // Start is called before the first frame update
    void Start()
    {
        mainCamera = GameObject.FindGameObjectWithTag("MainCamera");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void TestSelectedStack()
    {

        mainCamera.GetComponent<OrbitCamera>().target.GetComponent<JengaManager>().TestStack();
    }
}
