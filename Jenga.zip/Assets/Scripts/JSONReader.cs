using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using System.Collections;
using UnityEngine.Networking;
using TMPro;

[Serializable]
public class StudentsData
{
    public int id;
    public string subject;
    public string grade;
    public int mastery;
    public string domainid;
    public string domain;
    public string cluster;
    public string standardid;
    public string standarddescription;

}

[Serializable]
public class RootObject
{
    public StudentsData[] studentsDatas;
}

public class JSONReader : MonoBehaviour
{
    public RootObject rootObject;
    public JengaMaker jengaMaker;
    private string URL = "https://ga1vqcu3o1.execute-api.us-east-1.amazonaws.com/Assessment/stack";

    private void Awake()
    {
        GET();

    }

    public void GET()
    {
        StartCoroutine("GetData");
    }

    IEnumerator GetData()
    {

        using (UnityWebRequest www = UnityWebRequest.Get(URL))
        {

            www.SetRequestHeader("Accept", "application/json");

            yield return www.SendWebRequest();

            var serverDataRecieved = www.downloadHandler.text;


            RootObject rootObject = JsonUtility.FromJson<RootObject>("{\"studentsDatas\":" + serverDataRecieved + "}");
            jengaMaker.CreateJenga(rootObject.studentsDatas);

        }
    }
}